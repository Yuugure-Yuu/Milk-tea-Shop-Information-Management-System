# SDU_Restaurant_Master
 C语言程序课程设计大作业_中小饭店点餐系统

软件名称：驰名全宙的山大奶茶连锁店系统
制作者：钱克洋 张宇轩 刘力凯
一共有23个代码文件，4537行代码

管理员账号为admin，密码为123456
服务员账号为waiter，密码为111111
经理账号为manager，密码为666666

Code文件夹中存放代码和数据文件
Project文件夹中存储项目工程文件和可执行文件

本项目使用windows 10环境下的Visual Studio 19制作
若环境不同，调试运行时可能产生乱码，可选择使用可执行文件运行

可执行文件：Project\SDU_Reataurant_Master\SDU_Restaurant_Master.exe
不可移动


课程设计报告：《〈中小饭店点餐系统〉的设计和实现》

