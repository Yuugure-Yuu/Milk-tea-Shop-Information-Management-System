/************************************************************************
* �ļ����ƣ� main.c

* ���빦�ܣ�
*     ���ļ�Ϊ��������ڣ�ʵ��ϵͳ�����С�

*************************************************************************/
#include <windows.h>
#include "./Staff/Staff.h"
#include "./File/File.h"
#include "./Log_in/Log_in.h"
#include "./Admin/Admin.h"
#include "./Waiter/Waiter.h"
#include "./Manage/Manage.h"

int main()
{
	
	pList head, p;
	char staff[] = "../../Code/Data/Staff.txt";
	int (*pF[3])() = { Ui_waiter, Ui_manage, Ui_admin };
	
	FILE* fp;
	fp = File_open(staff);
	
	head = File_read(fp, sizeof(struct staff_t));
	p = head;
	if (p->pNext == NULL)
	{
		Login_initManager(fp, head);
	}
	p = p->pNext;
	if (p->pNext == NULL)
	{
		Login_init(fp, head);
	}
	

	while (1)
	{
		fclose(fp);
		if (pF[Log_in(head)]() == 1)
		{
			break;
		}

		fp = File_open(staff);
		head = File_read(fp, sizeof(struct staff_t));
	}
	system("cls");
	printf("\n\n\n\t\t\t���˳�ϵͳ");
	return 0;
}